
                    <div class="modal fade" id="signin_Modal">
                                  <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-check"></i>&nbsp;Sign In Client | Agent | Manager</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                          <center><div id="loader2"></div></center>
                                          <p>Sign into your Account</p>
                                          
                                         
                                       
                                            <div class="form-group">
                                                    
                                               </div>
                                            <div class="form-group">
                                                    <button type="button" class="btn  btn-lg btn-block client" style="color:#18161e"> CLIENT</button>
                                                     <button type="button" class="btn  btn-lg btn-block agent" style="color:#fff;background:#18161e">AGENT</button>
                                                     <button type="button" class="btn  btn-lg btn-block manager" style="color:#18161e">WASTE MANAGER</button>
                                               </div>
                                               
                                                <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                               
                                                 </div>
                                       
                                      </div>
                                     
                                    </div>
                                  </div>
                                </div>
                    <div class="modal fade" id="signup_Modal">
                                  <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                      <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel"><i class="fa fa-check"></i>&nbsp;Sign Up Client | Agent | Manager</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                          <span aria-hidden="true">&times;</span>
                                        </button>
                                      </div>
                                      <div class="modal-body">
                                          <center><div id="loader2"></div></center>
                                          <p>Create a free Account</p>
                                          
                                         
                                       
                                            <div class="form-group">
                                                    
                                               </div>
                                            <div class="form-group">
                                                    <button type="button" class="btn  btn-lg btn-block clientsignup" style="background:#198754;color:#fff"> CLIENT</button>
                                                     <button type="button" class="btn  btn-lg btn-block agentsignup" style="background:#198754;color:#fff">AGENT</button>
                                                     <button type="button" class="btn  btn-lg btn-block managersignup" style="background:#198754;color:#fff">WASTE MANAGER</button>
                                               </div>
                                              
                                                <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                               
                                                 </div>
                                       
                                      </div>
                                     
                                    </div>
                                  </div>
                                </div>